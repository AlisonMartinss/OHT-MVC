package MVC.oht;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MvcOhtApplication {

	public static void main(String[] args) {
		SpringApplication.run(MvcOhtApplication.class, args);
	}

}
